# Simple Video Chat WebRTC

### By using [simple-peer](https://github.com/feross/simple-peer), this web app connects video chat between two clients.

## How To Use

Install dependencies - npm install  
Start - npm start  

For development run watchify - npm run watch  

Open localhost in two browser tabs.
